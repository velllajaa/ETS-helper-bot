import fs from 'fs';
import path from 'path';

export interface ShiftLogEntry {
  timeSlot: string; // e.g. "14:00"
  players: number;
  ratingEmoji: string;
  timestamp: number; // unix timestamp in seconds
}

export interface BotData {
  date: string; // YYYY-MM-DD (Jakarta time)
  week: string; // YYYY-Www (Jakarta time)
  logsToday: Record<string, ShiftLogEntry>; // key: "14:00", value: ShiftLogEntry
  bmts: {
    today: number;
    thisWeek: number;
  };
  tryouts: {
    today: number;
    successfulEver: number;
    unsuccessfulEver: number;
    thisWeek: number;
  };
  recentActions: {
    id: string;
    type: 'logs' | 'bmt' | 'tryoutlog' | 'army' | 'summary' | 'undolog' | 'bmtundo' | 'tryoutsundo';
    title: string;
    details: string;
    timestamp: number;
    user?: string;
    meta?: {
      timeSlot?: string;
      tryoutType?: 'Succesfull' | 'Unsuccesfull';
      [key: string]: unknown;
    };
  }[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'bot_data.json');

// Get current date string and ISO week in Asia/Jakarta (WIB = UTC+7)
export function getJakartaDate(): { dateStr: string; weekStr: string; now: Date } {
  const now = new Date();
  // Format to Jakarta date
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const dateStr = formatter.format(now); // "YYYY-MM-DD"

  // Calculate ISO week for Jakarta
  const jakartaTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
  const d = new Date(Date.UTC(jakartaTime.getFullYear(), jakartaTime.getMonth(), jakartaTime.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  const weekStr = `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;

  return { dateStr, weekStr, now: jakartaTime };
}

// Convert "14:30" today in Jakarta to Unix timestamp (seconds)
export function getJakartaUnixTimestamp(timeSlot: string): number {
  const { dateStr } = getJakartaDate();
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hours, minutes] = timeSlot.split(':').map(Number);

  // WIB is UTC+7, so UTC hour = hours - 7
  const utcDate = new Date(Date.UTC(year, month - 1, day, hours - 7, minutes, 0));
  return Math.floor(utcDate.getTime() / 1000);
}

// Today's date unix timestamp in seconds (for <t:DATE_TIMESTAMP:D>)
export function getJakartaTodayDateTimestamp(): number {
  const { dateStr } = getJakartaDate();
  const [year, month, day] = dateStr.split('-').map(Number);
  // Midnight WIB (17:00 UTC previous day)
  const utcDate = new Date(Date.UTC(year, month - 1, day, 0 - 7, 0, 0));
  return Math.floor(utcDate.getTime() / 1000);
}

// Rating based on player count
export function getRatingEmoji(players: number): string {
  if (players >= 1 && players <= 3) return '🔴';
  if (players >= 4 && players <= 7) return '🟡';
  if (players >= 8 && players <= 13) return '🟢';
  if (players > 13) return '🔵';
  return '🔴';
}

function getDefaultData(): BotData {
  const { dateStr, weekStr } = getJakartaDate();
  return {
    date: dateStr,
    week: weekStr,
    logsToday: {},
    bmts: {
      today: 0,
      thisWeek: 0,
    },
    tryouts: {
      today: 0,
      successfulEver: 17,
      unsuccessfulEver: 174,
      thisWeek: 5,
    },
    recentActions: [],
  };
}

export function loadBotData(): BotData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DATA_FILE)) {
      const initial = getDefaultData();
      fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2), 'utf8');
      return initial;
    }

    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const data: BotData = JSON.parse(raw);

    // Check daily and weekly resets
    const { dateStr, weekStr } = getJakartaDate();
    let modified = false;

    if (data.date !== dateStr) {
      // Daily reset: logsToday, bmts.today, tryouts.today
      data.date = dateStr;
      data.logsToday = {};
      data.bmts.today = 0;
      data.tryouts.today = 0;
      modified = true;
    }

    if (data.week !== weekStr) {
      // Weekly reset: bmts.thisWeek, tryouts.thisWeek
      data.week = weekStr;
      data.bmts.thisWeek = 0;
      data.tryouts.thisWeek = 0;
      modified = true;
    }

    if (modified) {
      saveBotData(data);
    }

    return data;
  } catch (err) {
    console.error('Error loading bot data, resetting to default:', err);
    return getDefaultData();
  }
}

export function saveBotData(data: BotData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to save bot data:', err);
  }
}

// Revert last shift log (30 menit)
export function undoLogLast(botData: BotData, userTag = 'Discord'): { success: boolean; message: string; removedSlot?: string } {
  // Find most recent log action
  const actionIndex = botData.recentActions.findIndex((a) => a.type === 'logs');
  let removedSlot: string | undefined;

  if (actionIndex !== -1) {
    const action = botData.recentActions[actionIndex];
    if (action.meta?.timeSlot && botData.logsToday[action.meta.timeSlot]) {
      removedSlot = action.meta.timeSlot;
    } else {
      // Fallback: extract slot from title e.g. "/logs 14:30"
      const match = action.title.match(/(\d{2}:\d{2})/);
      if (match && botData.logsToday[match[1]]) {
        removedSlot = match[1];
      }
    }
    // Remove the action from recent actions
    botData.recentActions.splice(actionIndex, 1);
  }

  // If slot not determined from recent actions, remove the latest logged slot in logsToday
  if (!removedSlot) {
    const recordedSlots = Object.keys(botData.logsToday);
    if (recordedSlots.length === 0) {
      return { success: false, message: 'Tidak ada logs 30 menit yang dapat di-undo untuk hari ini!' };
    }
    // Pick the one with the highest timestamp or slot
    recordedSlots.sort((a, b) => (botData.logsToday[b]?.timestamp || 0) - (botData.logsToday[a]?.timestamp || 0));
    removedSlot = recordedSlots[0];
  }

  const deletedEntry = botData.logsToday[removedSlot];
  delete botData.logsToday[removedSlot];

  // Record undo action
  botData.recentActions.unshift({
    id: `undo_log_${Date.now()}`,
    type: 'undolog',
    title: `/undolog (${removedSlot})`,
    details: `Menghapus log shift ${removedSlot} (${deletedEntry?.players ?? '?'} players)`,
    timestamp: Date.now(),
    user: userTag,
  });
  if (botData.recentActions.length > 50) botData.recentActions.pop();

  saveBotData(botData);
  return {
    success: true,
    message: `Berhasil meng-undo log shift slot **${removedSlot}** (${deletedEntry?.players ?? 0} pemain telah dihapus dari database hari ini).`,
    removedSlot,
  };
}

// Revert last BMT log
export function undoBmtLast(botData: BotData, userTag = 'Discord'): { success: boolean; message: string } {
  const actionIndex = botData.recentActions.findIndex((a) => a.type === 'bmt');

  // Decrement counters (minimum 0)
  botData.bmts.today = Math.max(0, botData.bmts.today - 1);
  botData.bmts.thisWeek = Math.max(0, botData.bmts.thisWeek - 1);

  let details = 'Mengurangi 1x hitungan BMT hari ini & minggu ini';
  if (actionIndex !== -1) {
    const action = botData.recentActions[actionIndex];
    details = `Dihapus: ${action.title} - ${action.details}`;
    botData.recentActions.splice(actionIndex, 1);
  } else if (botData.bmts.today === 0 && botData.bmts.thisWeek === 0) {
    // Both were already 0 and no recent action
    return { success: false, message: 'Tidak ada data log BMT yang dapat di-undo (hitungan sudah 0)!' };
  }

  // Record undo action
  botData.recentActions.unshift({
    id: `undo_bmt_${Date.now()}`,
    type: 'bmtundo',
    title: `/bmtundo`,
    details: `Menghapus 1x BMT. Sisa today: ${botData.bmts.today}, this week: ${botData.bmts.thisWeek}`,
    timestamp: Date.now(),
    user: userTag,
  });
  if (botData.recentActions.length > 50) botData.recentActions.pop();

  saveBotData(botData);
  return {
    success: true,
    message: `Berhasil meng-undo 1x log BMT!\n• BMT Hari Ini: **${botData.bmts.today}**\n• BMT Minggu Ini: **${botData.bmts.thisWeek}**`,
  };
}

// Revert last Tryouts log
export function undoTryoutLast(botData: BotData, userTag = 'Discord'): { success: boolean; message: string } {
  const actionIndex = botData.recentActions.findIndex((a) => a.type === 'tryoutlog');

  let type: 'Succesfull' | 'Unsuccesfull' = 'Unsuccesfull';
  let removedDetails = '';

  if (actionIndex !== -1) {
    const action = botData.recentActions[actionIndex];
    if (action.meta?.tryoutType) {
      type = action.meta.tryoutType;
    } else if (action.title.includes('Succesfull')) {
      type = 'Succesfull';
    } else {
      type = 'Unsuccesfull';
    }
    removedDetails = `${action.title} (${action.details})`;
    botData.recentActions.splice(actionIndex, 1);
  }

  // Decrement counters
  botData.tryouts.today = Math.max(0, botData.tryouts.today - 1);
  botData.tryouts.thisWeek = Math.max(0, botData.tryouts.thisWeek - 1);
  if (type === 'Succesfull') {
    botData.tryouts.successfulEver = Math.max(0, botData.tryouts.successfulEver - 1);
  } else {
    botData.tryouts.unsuccessfulEver = Math.max(0, botData.tryouts.unsuccessfulEver - 1);
  }

  // Record undo action
  botData.recentActions.unshift({
    id: `undo_tryout_${Date.now()}`,
    type: 'tryoutsundo',
    title: `/tryouts undo`,
    details: `Menghapus 1x Tryout (${type}). Sisa today: ${botData.tryouts.today}, total ${type}: ${type === 'Succesfull' ? botData.tryouts.successfulEver : botData.tryouts.unsuccessfulEver}`,
    timestamp: Date.now(),
    user: userTag,
  });
  if (botData.recentActions.length > 50) botData.recentActions.pop();

  saveBotData(botData);
  return {
    success: true,
    message: `Berhasil meng-undo 1x log Tryout (${type})!\n• Tryouts Hari Ini: **${botData.tryouts.today}**\n• Tryouts Minggu Ini: **${botData.tryouts.thisWeek}**\n• Total Successful: **${botData.tryouts.successfulEver}**\n• Total Unsuccessful: **${botData.tryouts.unsuccessfulEver}**`,
  };
}

