import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  ButtonInteraction,
} from 'discord.js';
import {
  loadBotData,
  saveBotData,
  getJakartaUnixTimestamp,
  getJakartaTodayDateTimestamp,
  getRatingEmoji,
  BotData,
  undoLogLast,
  undoBmtLast,
  undoTryoutLast,
} from './dataStore.js';

export const BOT_CONFIG = {
  token: process.env.DISCORD_TOKEN || 'MTU1MDM2NjMzMzE3NzMwNzE0Ng.GxmK83.ttGwqWKLX87US1zDhP6VT2FN1JY6EkvKdvGkAU',
  clientId: process.env.DISCORD_CLIENT_ID || '1550366333177307146',
  inviteUrl: 'https://discord.com/oauth2/authorize?client_id=1550366333177307146&permissions=8&integration_type=0&scope=bot',
};

export const TIME_SLOTS = [
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
  '18:30',
  '19:00',
  '19:30',
  '20:00',
] as const;

export interface BotStatusInfo {
  ready: boolean;
  username: string;
  tag: string;
  id: string;
  ping: number;
  uptimeSeconds: number;
  guildsCount: number;
  loginError: string | null;
  lastConnected: string | null;
}

let clientInstance: Client | null = null;
let botStatusInfo: BotStatusInfo = {
  ready: false,
  username: 'ETS Helper Bot',
  tag: 'ETS Helper#0000',
  id: BOT_CONFIG.clientId,
  ping: -1,
  uptimeSeconds: 0,
  guildsCount: 0,
  loginError: null,
  lastConnected: null,
};

// Cache for copyable messages by ID so button click can retrieve raw text
const copyCache = new Map<string, string>();

export function getBotStatus(): BotStatusInfo {
  if (clientInstance && clientInstance.isReady()) {
    botStatusInfo.ready = true;
    botStatusInfo.username = clientInstance.user.username;
    botStatusInfo.tag = clientInstance.user.tag;
    botStatusInfo.id = clientInstance.user.id;
    botStatusInfo.ping = clientInstance.ws.ping;
    botStatusInfo.uptimeSeconds = Math.floor((clientInstance.uptime || 0) / 1000);
    botStatusInfo.guildsCount = clientInstance.guilds.cache.size;
  }
  return botStatusInfo;
}

// Build Slash Commands definitions
function createSlashCommands() {
  const logsCmd = new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Laporan shift tiap 30 menit (14:00 - 20:00 WIB)')
    .addStringOption((opt) =>
      opt
        .setName('waktu')
        .setDescription('Pilih jam shift')
        .setRequired(true)
        .addChoices(
          ...TIME_SLOTS.map((slot) => ({ name: slot, value: slot }))
        )
    )
    .addIntegerOption((opt) =>
      opt
        .setName('players')
        .setDescription('Jumlah pemain in game')
        .setRequired(true)
        .setMinValue(0)
    );

  const bmtCmd = new SlashCommandBuilder()
    .setName('bmt')
    .setDescription('Mencatat kegiatan Basic Military Training (BMT)')
    .addIntegerOption((opt) =>
      opt
        .setName('attendees_number')
        .setDescription('Jumlah peserta BMT')
        .setRequired(true)
        .setMinValue(0)
    )
    .addStringOption((opt) =>
      opt
        .setName('attendees_username')
        .setDescription('Username peserta (contoh: Vulture and sayurkol910)')
        .setRequired(true)
    )
    .addIntegerOption((opt) =>
      opt
        .setName('passed')
        .setDescription('Jumlah peserta lulus')
        .setRequired(true)
        .setMinValue(0)
    )
    .addIntegerOption((opt) =>
      opt
        .setName('failed')
        .setDescription('Jumlah peserta gagal')
        .setRequired(true)
        .setMinValue(0)
    );

  const tryoutCmd = new SlashCommandBuilder()
    .setName('tryoutlog')
    .setDescription('Mencatat kegiatan tryout')
    .addStringOption((opt) =>
      opt
        .setName('type')
        .setDescription('Tipe tryout (Succesfull atau Unsuccesfull)')
        .setRequired(true)
        .addChoices(
          { name: 'Succesfull', value: 'Succesfull' },
          { name: 'Unsuccesfull', value: 'Unsuccesfull' }
        )
    )
    .addIntegerOption((opt) =>
      opt
        .setName('attendees')
        .setDescription('Jumlah peserta')
        .setRequired(true)
        .setMinValue(0)
    )
    .addIntegerOption((opt) =>
      opt
        .setName('passed')
        .setDescription('Jumlah peserta yang lulus')
        .setRequired(true)
        .setMinValue(0)
    )
    .addIntegerOption((opt) =>
      opt
        .setName('failed')
        .setDescription('Jumlah peserta yang gagal')
        .setRequired(true)
        .setMinValue(0)
    )
    .addStringOption((opt) =>
      opt
        .setName('current_rank')
        .setDescription('Current rank (contoh: Chief of Staff, Deputy Commandant, CoS)')
        .setRequired(false)
    );

  const armyCmd = new SlashCommandBuilder()
    .setName('army')
    .setDescription('Mencatat data User dan Rank Army')
    .addStringOption((opt) =>
      opt
        .setName('user')
        .setDescription('User / Nama prajurit (atau mention)')
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName('rank')
        .setDescription('Pangkat / Rank')
        .setRequired(true)
    );

  const summaryCmd = new SlashCommandBuilder()
    .setName('summary')
    .setDescription('Memberikan ringkasan data logs 30 menit hari ini (AEST LOGS SUMMARY)');

  // 1. /undolog - Menghapus logs 30 menit terakhir sebanyak 1x
  const undoLogCmd = new SlashCommandBuilder()
    .setName('undolog')
    .setDescription('Menghapus logs 30 menit yang terakhir dimasukkan sebanyak 1x');

  // 2. /bmtundo - Menghapus logs BMT terakhir 1x
  const undoBmtCmd = new SlashCommandBuilder()
    .setName('bmtundo')
    .setDescription('Menghapus logs BMT terakhir 1x');

  // 3. /tryouts undo & /tryoutsundo - Menghapus logs tryout terakhir 1x
  const tryoutsCmd = new SlashCommandBuilder()
    .setName('tryouts')
    .setDescription('Kelola data tryouts')
    .addSubcommand((sub) =>
      sub.setName('undo').setDescription('Menghapus logs tryout terakhir 1x')
    );

  const undoTryoutsCmd = new SlashCommandBuilder()
    .setName('tryoutsundo')
    .setDescription('Menghapus logs tryout terakhir 1x');

  return [
    logsCmd.toJSON(),
    bmtCmd.toJSON(),
    tryoutCmd.toJSON(),
    armyCmd.toJSON(),
    summaryCmd.toJSON(),
    undoLogCmd.toJSON(),
    undoBmtCmd.toJSON(),
    tryoutsCmd.toJSON(),
    undoTryoutsCmd.toJSON(),
  ];
}

// Register commands to Discord REST API
async function registerCommands(token: string, clientId: string) {
  try {
    console.log('[Discord] Registering slash commands globally...');
    const rest = new REST({ version: '10' }).setToken(token);
    const commands = createSlashCommands();

    await rest.put(Routes.applicationCommands(clientId), {
      body: commands,
    });
    console.log('[Discord] Successfully registered global slash commands: /logs, /bmt, /tryoutlog, /army, /summary, /undolog, /bmtundo, /tryouts undo, /tryoutsundo');
  } catch (err) {
    console.error('[Discord] Failed to register slash commands:', err);
  }
}

// Format generators used by both Bot and Web API
export function formatLogsOutput(waktu: string, players: number): { text: string; timestamp: number; ratingEmoji: string } {
  const timestamp = getJakartaUnixTimestamp(waktu);
  const ratingEmoji = getRatingEmoji(players);

  const text = `Time: <t:${timestamp}:t>\nPlayers in game: ${players}\nRating: ${ratingEmoji}\nPing: <@1381618249070022796>`;
  return { text, timestamp, ratingEmoji };
}

export function formatBmtOutput(
  attendeesNumber: number,
  attendeesUsername: string,
  passed: number,
  failed: number,
  bmtsToday: number,
  bmtsThisWeek: number
): string {
  return [
    '## <:ETS:962722934508634122> | Basic Military Training',
    '> Host: <@1495316869131927634>',
    '> Co host: N/A',
    `> Attendees: ${attendeesNumber} (${attendeesUsername})`,
    `> Passed: ${passed}`,
    `> Failed: ${failed}`,
    `> BMTs today: ${bmtsToday}`,
    `> BMTs this week: ${bmtsThisWeek}`,
    '> Ping: <@961066817919516672> <@971106636066332762>',
    '> Proof: 👇',
  ].join('\n');
}

export function formatTryoutOutput(
  type: string,
  attendees: number,
  passed: number,
  failed: number,
  currentRank: string,
  tryoutsToday: number,
  successfulEver: number,
  unsuccessfulEver: number,
  tryoutsThisWeek: number
): string {
  const title = type === 'Succesfull' ? 'Succesfull Tryout' : 'Unsuccesfull Tryout';
  const rank = currentRank?.trim() || 'CoS';

  return [
    `## <:ETS:962722934508634122> | ${title}`,
    '> Host: <@1495316869131927634>',
    '> Co Host: N/A',
    `> Current Rank: ${rank}`,
    `> Attendees: ${attendees}`,
    `> Passed: \`${passed}\``,
    `> Failed: \`${failed}\``,
    `> Total tryouts today: ${tryoutsToday}`,
    `> Total Successful tryouts ever: ${successfulEver}`,
    `> Total Unsuccessful tryouts ever: ${unsuccessfulEver}`,
    `> Total tryouts for this week: ${tryoutsThisWeek}`,
    '> Ping: <@961066817919516672>',
    '> Proof: N/A',
  ].join('\n');
}

export function formatArmyOutput(user: string, rank: string): string {
  return [
    `User: ${user}`,
    `Rank: ${rank}`,
    'Ping: <@1136972263988678727>',
  ].join('\n');
}

export function formatSummaryOutput(botData: BotData): string {
  const dateTimestamp = getJakartaTodayDateTimestamp();
  const lines: string[] = [
    `<t:${dateTimestamp}:D>`,
    '',
    '**AEST LOGS SUMMARY**',
  ];

  // Output all recorded time slots in order
  let hasSlots = false;
  for (const slot of TIME_SLOTS) {
    if (botData.logsToday[slot]) {
      const entry = botData.logsToday[slot];
      lines.push(`<t:${entry.timestamp}:t> - (${entry.players})`);
      hasSlots = true;
    }
  }

  // If no logs recorded yet, output template with 0s or empty
  if (!hasSlots) {
    for (const slot of TIME_SLOTS) {
      const ts = getJakartaUnixTimestamp(slot);
      lines.push(`<t:${ts}:t> - (0)`);
    }
  }

  lines.push('');
  lines.push('<@1381618249070022796>');
  lines.push('<@1207048828306460716>');

  return lines.join('\n');
}

// Handle slash command interactions
async function handleChatInputCommand(interaction: ChatInputCommandInteraction) {
  const { commandName } = interaction;
  const botData = loadBotData();

  if (commandName === 'logs') {
    const waktu = interaction.options.getString('waktu', true);
    const players = interaction.options.getInteger('players', true);

    const { text, timestamp, ratingEmoji } = formatLogsOutput(waktu, players);

    // Save into botData
    botData.logsToday[waktu] = {
      timeSlot: waktu,
      players,
      ratingEmoji,
      timestamp,
    };
    botData.recentActions.unshift({
      id: interaction.id,
      type: 'logs',
      title: `/logs ${waktu}`,
      details: `${players} players (${ratingEmoji})`,
      timestamp: Date.now(),
      user: interaction.user.tag,
      meta: { timeSlot: waktu },
    });
    if (botData.recentActions.length > 50) botData.recentActions.pop();
    saveBotData(botData);

    const copyBtnId = `copy_${interaction.id}`;
    copyCache.set(copyBtnId, text);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(copyBtnId)
        .setLabel('📋 Copy Teks')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: text,
      components: [row],
    });
  } else if (commandName === 'bmt') {
    const attendeesNumber = interaction.options.getInteger('attendees_number', true);
    const attendeesUsername = interaction.options.getString('attendees_username', true);
    const passed = interaction.options.getInteger('passed', true);
    const failed = interaction.options.getInteger('failed', true);

    // Increment counters
    botData.bmts.today += 1;
    botData.bmts.thisWeek += 1;

    botData.recentActions.unshift({
      id: interaction.id,
      type: 'bmt',
      title: `/bmt (${attendeesNumber} attendees)`,
      details: `Passed: ${passed}, Failed: ${failed}`,
      timestamp: Date.now(),
      user: interaction.user.tag,
    });
    if (botData.recentActions.length > 50) botData.recentActions.pop();
    saveBotData(botData);

    const text = formatBmtOutput(
      attendeesNumber,
      attendeesUsername,
      passed,
      failed,
      botData.bmts.today,
      botData.bmts.thisWeek
    );

    const copyBtnId = `copy_${interaction.id}`;
    copyCache.set(copyBtnId, text);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(copyBtnId)
        .setLabel('📋 Copy Teks')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: text,
      components: [row],
    });
  } else if (commandName === 'tryoutlog') {
    const type = interaction.options.getString('type', true);
    const attendees = interaction.options.getInteger('attendees', true);
    const passed = interaction.options.getInteger('passed', true);
    const failed = interaction.options.getInteger('failed', true);
    const currentRank = interaction.options.getString('current_rank') || 'CoS';

    // Update counters
    botData.tryouts.today += 1;
    botData.tryouts.thisWeek += 1;
    if (type === 'Succesfull') {
      botData.tryouts.successfulEver += 1;
    } else {
      botData.tryouts.unsuccessfulEver += 1;
    }

    botData.recentActions.unshift({
      id: interaction.id,
      type: 'tryoutlog',
      title: `/tryoutlog ${type}`,
      details: `Passed: ${passed}, Failed: ${failed}, Rank: ${currentRank}`,
      timestamp: Date.now(),
      user: interaction.user.tag,
      meta: { tryoutType: type as 'Succesfull' | 'Unsuccesfull' },
    });
    if (botData.recentActions.length > 50) botData.recentActions.pop();
    saveBotData(botData);

    const text = formatTryoutOutput(
      type,
      attendees,
      passed,
      failed,
      currentRank,
      botData.tryouts.today,
      botData.tryouts.successfulEver,
      botData.tryouts.unsuccessfulEver,
      botData.tryouts.thisWeek
    );

    const copyBtnId = `copy_${interaction.id}`;
    copyCache.set(copyBtnId, text);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(copyBtnId)
        .setLabel('📋 Copy Teks')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: text,
      components: [row],
    });
  } else if (commandName === 'army') {
    const user = interaction.options.getString('user', true);
    const rank = interaction.options.getString('rank', true);

    botData.recentActions.unshift({
      id: interaction.id,
      type: 'army',
      title: `/army ${user}`,
      details: `Rank: ${rank}`,
      timestamp: Date.now(),
      user: interaction.user.tag,
    });
    if (botData.recentActions.length > 50) botData.recentActions.pop();
    saveBotData(botData);

    const text = formatArmyOutput(user, rank);

    const copyBtnId = `copy_${interaction.id}`;
    copyCache.set(copyBtnId, text);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(copyBtnId)
        .setLabel('📋 Copy Teks')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: text,
      components: [row],
    });
  } else if (commandName === 'summary') {
    const text = formatSummaryOutput(botData);

    botData.recentActions.unshift({
      id: interaction.id,
      type: 'summary',
      title: `/summary`,
      details: `Generated summary for ${Object.keys(botData.logsToday).length} logged slots`,
      timestamp: Date.now(),
      user: interaction.user.tag,
    });
    if (botData.recentActions.length > 50) botData.recentActions.pop();
    saveBotData(botData);

    const copyBtnId = `copy_${interaction.id}`;
    copyCache.set(copyBtnId, text);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(copyBtnId)
        .setLabel('📋 Copy Teks')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: text,
      components: [row],
    });
  } else if (commandName === 'undolog') {
    // 1. Undolog --> Menghapus logs 30 menit itu yang terakhir dimasukkan sebanyak 1x
    const result = undoLogLast(botData, interaction.user.tag);
    await interaction.reply({
      content: result.success
        ? `↩️ **[UNDO LOGS 30 MENIT]**\n${result.message}`
        : `⚠️ **Gagal Undo:** ${result.message}`,
      ephemeral: !result.success,
    });
  } else if (commandName === 'bmtundo') {
    // 2. bmtundo --> Menghapus logs BMT terakhir 1x
    const result = undoBmtLast(botData, interaction.user.tag);
    await interaction.reply({
      content: result.success
        ? `↩️ **[UNDO BMT LOG]**\n${result.message}`
        : `⚠️ **Gagal Undo:** ${result.message}`,
      ephemeral: !result.success,
    });
  } else if (commandName === 'tryouts' || commandName === 'tryoutsundo') {
    // 3. tryouts undo / tryoutsundo --> Menghapus logs tryout terakhir 1x
    const result = undoTryoutLast(botData, interaction.user.tag);
    await interaction.reply({
      content: result.success
        ? `↩️ **[UNDO TRYOUT LOG]**\n${result.message}`
        : `⚠️ **Gagal Undo:** ${result.message}`,
      ephemeral: !result.success,
    });
  }
}

// Handle Copy button clicks
async function handleButtonInteraction(interaction: ButtonInteraction) {
  if (interaction.customId.startsWith('copy_')) {
    const text = copyCache.get(interaction.customId);
    if (text) {
      await interaction.reply({
        content: `**📋 Teks Siap Di-Copy:**\n\`\`\`\n${text}\n\`\`\`\n*(Tekan dan tahan pada kotak di atas atau pilih semua untuk menyalin)*`,
        ephemeral: true,
      });
    } else {
      // If expired from memory, grab message content
      const msgContent = interaction.message.content;
      await interaction.reply({
        content: `**📋 Teks Siap Di-Copy:**\n\`\`\`\n${msgContent}\n\`\`\`\n*(Tekan dan tahan pada kotak di atas atau pilih semua untuk menyalin)*`,
        ephemeral: true,
      });
    }
  }
}

// Initialize and start Discord Client
export async function startDiscordBot() {
  if (clientInstance) {
    return clientInstance;
  }

  const token = BOT_CONFIG.token;
  const clientId = BOT_CONFIG.clientId;

  if (!token) {
    console.warn('[Discord] No DISCORD_TOKEN provided. Skipping bot connection.');
    botStatusInfo.loginError = 'Token Discord belum diset.';
    return null;
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });

  client.once('ready', async (c) => {
    console.log(`[Discord] Logged in as ${c.user.tag} (ID: ${c.user.id})`);
    botStatusInfo.ready = true;
    botStatusInfo.username = c.user.username;
    botStatusInfo.tag = c.user.tag;
    botStatusInfo.id = c.user.id;
    botStatusInfo.lastConnected = new Date().toISOString();
    botStatusInfo.loginError = null;

    // Register slash commands on login
    await registerCommands(token, clientId);
  });

  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        await handleChatInputCommand(interaction);
      } else if (interaction.isButton()) {
        await handleButtonInteraction(interaction);
      }
    } catch (err: any) {
      console.error('[Discord] Error handling interaction:', err);
      if (interaction.isRepliable() && !interaction.replied) {
        await interaction.reply({
          content: `⚠️ Terjadi error saat memproses command: ${err?.message || 'Unknown error'}`,
          ephemeral: true,
        });
      }
    }
  });

  client.on('error', (err) => {
    console.error('[Discord] Client Error:', err);
    botStatusInfo.loginError = err.message;
  });

  try {
    console.log('[Discord] Connecting to Discord Gateway...');
    await client.login(token);
    clientInstance = client;
  } catch (err: any) {
    console.error('[Discord] Failed to login to Discord:', err);
    botStatusInfo.loginError = err?.message || 'Gagal login ke Discord Gateway';
  }

  return client;
}
