import { useState } from 'react';
import { Undo2, Clock, Award, Target, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { BotData } from '../types';

interface UndoControlsPanelProps {
  botData: BotData | null;
  onRefreshData: () => void;
}

export function UndoControlsPanel({ botData, onRefreshData }: UndoControlsPanelProps) {
  const [loadingType, setLoadingType] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleUndo = async (type: 'logs' | 'bmt' | 'tryout', label: string) => {
    setLoadingType(type);
    setStatusMessage(null);
    try {
      const res = await fetch('/api/undo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      });
      const data = await res.json();
      if (data.success) {
        setStatusMessage({ type: 'success', text: data.message });
        onRefreshData();
      } else {
        setStatusMessage({ type: 'error', text: data.message || `Gagal melakukan undo ${label}` });
      }
    } catch (err) {
      console.error('Error undoing:', err);
      setStatusMessage({ type: 'error', text: 'Gagal terhubung ke server saat melakukan undo.' });
    } finally {
      setLoadingType(null);
      setTimeout(() => {
        setStatusMessage(null);
      }, 6000);
    }
  };

  // Find last action info for helper previews
  const lastLogAction = botData?.recentActions.find((a) => a.type === 'logs');
  const lastBmtAction = botData?.recentActions.find((a) => a.type === 'bmt');
  const lastTryoutAction = botData?.recentActions.find((a) => a.type === 'tryoutlog');

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:p-6 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Undo2 className="w-4 h-4 text-rose-400" />
            <span>Kontrol Undo Cepat (Web & Discord)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Membatalkan / menghapus 1x aksi log terakhir secara instan dan atomic (tersedia juga via Discord slash command).
          </p>
        </div>
        <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 w-fit">
          Atomic 1x Revert
        </span>
      </div>

      {statusMessage && (
        <div
          className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span className="whitespace-pre-line">{statusMessage.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* 1. Undolog */}
        <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 flex flex-col justify-between space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sky-400 font-semibold text-xs">
                <Clock className="w-3.5 h-3.5" />
                <span>1. /undolog</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Shift Log</span>
            </div>
            <p className="text-xs text-slate-300 font-medium">Menghapus Log 30 Menit Terakhir</p>
            <p className="text-[11px] text-slate-400 leading-snug">
              {lastLogAction ? (
                <>
                  Target: <span className="text-sky-300 font-mono">{lastLogAction.title}</span> ({lastLogAction.details})
                </>
              ) : (
                'Menghapus log shift slot terbaru hari ini dari database & summary.'
              )}
            </p>
          </div>
          <button
            onClick={() => handleUndo('logs', 'Log 30 Menit')}
            disabled={loadingType === 'logs'}
            className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-rose-300 hover:text-rose-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition disabled:opacity-50"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>{loadingType === 'logs' ? 'Memproses...' : 'Eksekusi /undolog (1x)'}</span>
          </button>
        </div>

        {/* 2. bmtundo */}
        <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 flex flex-col justify-between space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs">
                <Award className="w-3.5 h-3.5" />
                <span>2. /bmtundo</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">BMT Log</span>
            </div>
            <p className="text-xs text-slate-300 font-medium">Menghapus Log BMT Terakhir</p>
            <p className="text-[11px] text-slate-400 leading-snug">
              {lastBmtAction ? (
                <>
                  Target: <span className="text-indigo-300 font-mono">{lastBmtAction.title}</span> ({lastBmtAction.details})
                </>
              ) : (
                'Mengurangi 1x hitungan BMT today & this week, serta membatalkan entri BMT terakhir.'
              )}
            </p>
          </div>
          <button
            onClick={() => handleUndo('bmt', 'BMT Log')}
            disabled={loadingType === 'bmt'}
            className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-rose-300 hover:text-rose-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition disabled:opacity-50"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>{loadingType === 'bmt' ? 'Memproses...' : 'Eksekusi /bmtundo (1x)'}</span>
          </button>
        </div>

        {/* 3. tryouts undo */}
        <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 flex flex-col justify-between space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs">
                <Target className="w-3.5 h-3.5" />
                <span>3. /tryouts undo</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Tryouts Log</span>
            </div>
            <p className="text-xs text-slate-300 font-medium">Menghapus Log Tryout Terakhir</p>
            <p className="text-[11px] text-slate-400 leading-snug">
              {lastTryoutAction ? (
                <>
                  Target: <span className="text-amber-300 font-mono">{lastTryoutAction.title}</span> ({lastTryoutAction.details})
                </>
              ) : (
                'Mengurangi 1x counter tryout today, this week, dan counter successful / unsuccessful terkait.'
              )}
            </p>
          </div>
          <button
            onClick={() => handleUndo('tryout', 'Tryout Log')}
            disabled={loadingType === 'tryout'}
            className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-rose-300 hover:text-rose-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition disabled:opacity-50"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>{loadingType === 'tryout' ? 'Memproses...' : 'Eksekusi /tryouts undo (1x)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
