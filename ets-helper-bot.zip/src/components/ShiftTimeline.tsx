import { useState } from 'react';
import { Clock, Users, CheckCircle, AlertCircle, Plus } from 'lucide-react';
import { BotData, ShiftLogEntry } from '../types';

interface ShiftTimelineProps {
  botData: BotData | null;
  onQuickLog: (waktu: string, players: number) => Promise<void>;
}

const TIME_SLOTS = [
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
  '18:30',
  '19:00',
  '19:30',
  '20:00',
];

export function ShiftTimeline({ botData, onQuickLog }: ShiftTimelineProps) {
  const [modalSlot, setModalSlot] = useState<string | null>(null);
  const [playerInput, setPlayerInput] = useState<number>(5);
  const [submitting, setSubmitting] = useState(false);

  const logsToday = botData?.logsToday || {};

  const handleOpenModal = (slot: string) => {
    setModalSlot(slot);
    setPlayerInput(logsToday[slot]?.players ?? 5);
  };

  const handleSaveQuickLog = async () => {
    if (!modalSlot) return;
    setSubmitting(true);
    try {
      await onQuickLog(modalSlot, playerInput);
      setModalSlot(null);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:p-6 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>Jadwal Shift Log 30 Menit (14:00 - 20:00 WIB)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Setiap laporan dicatat untuk rangkuman <span className="text-slate-300 font-mono">/summary</span> harian.
          </p>
        </div>
        <span className="text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
          Terisi: <strong className="text-indigo-400">{Object.keys(logsToday).length}</strong> / 13 Slot
        </span>
      </div>

      {/* Grid of Slots */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5">
        {TIME_SLOTS.map((slot) => {
          const entry: ShiftLogEntry | undefined = logsToday[slot];
          const isFilled = Boolean(entry);

          return (
            <div
              key={slot}
              onClick={() => handleOpenModal(slot)}
              className={`p-3 rounded-xl border text-left cursor-pointer transition relative group ${
                isFilled
                  ? 'bg-slate-950/80 border-indigo-500/40 hover:border-indigo-400'
                  : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold mb-1.5">
                <span className={isFilled ? 'text-white' : 'text-slate-400'}>{slot}</span>
                {isFilled ? (
                  <span className="text-base">{entry.ratingEmoji}</span>
                ) : (
                  <Plus className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-300 transition" />
                )}
              </div>

              {isFilled ? (
                <div>
                  <div className="text-xs font-semibold text-indigo-300 flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    <span>{entry.players} players</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1 truncate font-mono">
                    &lt;t:{entry.timestamp}:t&gt;
                  </div>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 italic flex items-center gap-1">
                  <span>Belum diisi</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Log Modal */}
      {modalSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-sm font-bold text-white">
                Log Shift {modalSlot} WIB
              </h4>
              <button
                onClick={() => setModalSlot(null)}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-300 font-semibold block mb-1">
                Jumlah Pemain In Game:
              </label>
              <input
                type="number"
                min="0"
                value={playerInput}
                onChange={(e) => setPlayerInput(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setModalSlot(null)}
                className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white"
              >
                Batal
              </button>
              <button
                onClick={handleSaveQuickLog}
                disabled={submitting}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow transition"
              >
                {submitting ? 'Menyimpan...' : 'Simpan Log'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
