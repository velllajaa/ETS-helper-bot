import { useState } from 'react';
import { BotData } from '../types';
import { Award, Target, CheckCircle2, XCircle, Calendar, Clock, Edit2, Save, X } from 'lucide-react';

interface StatsCounterCardsProps {
  data: BotData | null;
  onUpdateCounters: (updates: Partial<BotData>) => Promise<void>;
}

export function StatsCounterCards({ data, onUpdateCounters }: StatsCounterCardsProps) {
  const [editing, setEditing] = useState(false);
  const [bmtsToday, setBmtsToday] = useState(data?.bmts.today ?? 0);
  const [bmtsWeek, setBmtsWeek] = useState(data?.bmts.thisWeek ?? 0);
  const [tryoutsToday, setTryoutsToday] = useState(data?.tryouts.today ?? 0);
  const [tryoutsWeek, setTryoutsWeek] = useState(data?.tryouts.thisWeek ?? 5);
  const [tryoutsSuccess, setTryoutsSuccess] = useState(data?.tryouts.successfulEver ?? 17);
  const [tryoutsUnsuccess, setTryoutsUnsuccess] = useState(data?.tryouts.unsuccessfulEver ?? 174);
  const [saving, setSaving] = useState(false);

  const startEdit = () => {
    if (data) {
      setBmtsToday(data.bmts.today);
      setBmtsWeek(data.bmts.thisWeek);
      setTryoutsToday(data.tryouts.today);
      setTryoutsWeek(data.tryouts.thisWeek);
      setTryoutsSuccess(data.tryouts.successfulEver);
      setTryoutsUnsuccess(data.tryouts.unsuccessfulEver);
    }
    setEditing(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onUpdateCounters({
        bmts: {
          today: Number(bmtsToday),
          thisWeek: Number(bmtsWeek),
        },
        tryouts: {
          today: Number(tryoutsToday),
          thisWeek: Number(tryoutsWeek),
          successfulEver: Number(tryoutsSuccess),
          unsuccessfulEver: Number(tryoutsUnsuccess),
        },
      });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const loggedSlotsCount = data ? Object.keys(data.logsToday).length : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <span>Statistik & Counter Real-Time</span>
            <span className="text-[10px] text-slate-400 font-normal lowercase bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
              Sinkron dengan Bot Discord
            </span>
          </h3>
        </div>

        {!editing ? (
          <button
            onClick={startEdit}
            className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition font-medium"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Koreksi Angka Manual</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1 px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Menyimpan...' : 'Simpan'}</span>
            </button>
            <button
              onClick={() => setEditing(false)}
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* BMT Today */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">BMT Hari Ini</span>
            <Award className="w-4 h-4 text-sky-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={bmtsToday}
                onChange={(e) => setBmtsToday(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-white">{data?.bmts.today ?? 0}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Reset harian (00:00 WIB)</span>
        </div>

        {/* BMT This Week */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">BMT Minggu Ini</span>
            <Calendar className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={bmtsWeek}
                onChange={(e) => setBmtsWeek(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-indigo-400">{data?.bmts.thisWeek ?? 0}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Reset mingguan (Senin)</span>
        </div>

        {/* Tryouts Today */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Tryouts Hari Ini</span>
            <Target className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={tryoutsToday}
                onChange={(e) => setTryoutsToday(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-emerald-400">{data?.tryouts.today ?? 0}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Mulai dari 0 tiap hari</span>
        </div>

        {/* Tryouts This Week */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Tryouts Minggu Ini</span>
            <Calendar className="w-4 h-4 text-amber-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={tryoutsWeek}
                onChange={(e) => setTryoutsWeek(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-amber-400">{data?.tryouts.thisWeek ?? 5}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Total minggu ini</span>
        </div>

        {/* Successful Tryouts Ever */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Successful Ever</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={tryoutsSuccess}
                onChange={(e) => setTryoutsSuccess(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-emerald-400">{data?.tryouts.successfulEver ?? 17}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Total sukses tersimpan</span>
        </div>

        {/* Unsuccessful Tryouts Ever */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Unsuccessful Ever</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="my-2">
            {editing ? (
              <input
                type="number"
                value={tryoutsUnsuccess}
                onChange={(e) => setTryoutsUnsuccess(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-lg font-bold text-white text-center"
              />
            ) : (
              <span className="text-2xl font-black text-rose-400">{data?.tryouts.unsuccessfulEver ?? 174}</span>
            )}
          </div>
          <span className="text-[11px] text-slate-500">Total gagal tersimpan</span>
        </div>
      </div>
    </div>
  );
}
