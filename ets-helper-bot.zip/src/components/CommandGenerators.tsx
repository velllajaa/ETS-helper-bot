import { useState } from 'react';
import { Copy, Check, Terminal, Play, Save, Flame, Clock, Award, Target, UserCheck, FileText } from 'lucide-react';
import { BotData } from '../types';

interface CommandGeneratorsProps {
  botData: BotData | null;
  onRefreshData: () => void;
}

const TIME_SLOTS = [
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
  '18:30',
  '19:00',
  '19:30',
  '20:00',
];

export function CommandGenerators({ botData, onRefreshData }: CommandGeneratorsProps) {
  const [activeTab, setActiveTab] = useState<'logs' | 'bmt' | 'tryoutlog' | 'army' | 'summary'>('logs');

  // Logs state
  const [logsTime, setLogsTime] = useState('14:30');
  const [logsPlayers, setLogsPlayers] = useState<number>(5);

  // BMT state
  const [bmtNumber, setBmtNumber] = useState<number>(2);
  const [bmtUsername, setBmtUsername] = useState('Vulture and sayurkol910');
  const [bmtPassed, setBmtPassed] = useState<number>(1);
  const [bmtFailed, setBmtFailed] = useState<number>(1);

  // Tryout state
  const [tryoutType, setTryoutType] = useState<'Succesfull' | 'Unsuccesfull'>('Unsuccesfull');
  const [tryoutAttendees, setTryoutAttendees] = useState<number>(0);
  const [tryoutPassed, setTryoutPassed] = useState<number>(0);
  const [tryoutFailed, setTryoutFailed] = useState<number>(0);
  const [tryoutRank, setTryoutRank] = useState('CoS');

  // Army state
  const [armyUser, setArmyUser] = useState('Agent_Alex');
  const [armyRank, setArmyRank] = useState('Lieutenant');

  // Generated results
  const [generatedText, setGeneratedText] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saveToDatabase, setSaveToDatabase] = useState(true);

  // Live rating helper
  const getRating = (players: number) => {
    if (players >= 1 && players <= 3) return { emoji: '🔴', label: '1-3 Pemain' };
    if (players >= 4 && players <= 7) return { emoji: '🟡', label: '4-7 Pemain' };
    if (players >= 8 && players <= 13) return { emoji: '🟢', label: '8-13 Pemain' };
    return { emoji: '🔵', label: '13+ Pemain' };
  };

  const currentRating = getRating(logsPlayers);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      let payload: any = { save: saveToDatabase };

      if (activeTab === 'logs') {
        payload = { ...payload, waktu: logsTime, players: Number(logsPlayers) };
      } else if (activeTab === 'bmt') {
        payload = {
          ...payload,
          attendeesNumber: Number(bmtNumber),
          attendeesUsername: bmtUsername,
          passed: Number(bmtPassed),
          failed: Number(bmtFailed),
        };
      } else if (activeTab === 'tryoutlog') {
        payload = {
          ...payload,
          type: tryoutType,
          attendees: Number(tryoutAttendees),
          passed: Number(tryoutPassed),
          failed: Number(tryoutFailed),
          currentRank: tryoutRank,
        };
      } else if (activeTab === 'army') {
        payload = { ...payload, user: armyUser, rank: armyRank };
      } else if (activeTab === 'summary') {
        payload = { ...payload };
      }

      const res = await fetch('/api/generate-preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: activeTab, payload }),
      });

      const data = await res.json();
      if (data.formattedText) {
        setGeneratedText(data.formattedText);
        if (saveToDatabase) {
          onRefreshData();
        }
      }
    } catch (err) {
      console.error('Error generating preview:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:p-6 shadow-xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>Slash Command Generator & Formatter</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Gunakan generator ini untuk mencoba format atau menghasilkan teks Discord siap kirim.
          </p>
        </div>

        {/* Command Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto">
          <button
            onClick={() => { setActiveTab('logs'); setGeneratedText(''); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'logs' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>/logs</span>
          </button>
          <button
            onClick={() => { setActiveTab('bmt'); setGeneratedText(''); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'bmt' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>/bmt</span>
          </button>
          <button
            onClick={() => { setActiveTab('tryoutlog'); setGeneratedText(''); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'tryoutlog' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>/tryoutlog</span>
          </button>
          <button
            onClick={() => { setActiveTab('army'); setGeneratedText(''); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'army' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>/army</span>
          </button>
          <button
            onClick={() => { setActiveTab('summary'); setGeneratedText(''); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'summary' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>/summary</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left column: Form Inputs */}
        <div className="lg:col-span-5 space-y-4">
          {activeTab === 'logs' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Waktu Shift (14:00 - 20:00 WIB):
                </label>
                <select
                  value={logsTime}
                  onChange={(e) => setLogsTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                >
                  {TIME_SLOTS.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot} WIB
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Jumlah Pemain in game:
                  </label>
                  <span className="text-xs font-medium text-slate-400 flex items-center gap-1">
                    Rating: <span className="text-sm">{currentRating.emoji}</span> ({currentRating.label})
                  </span>
                </div>
                <input
                  type="number"
                  min="0"
                  value={logsPlayers}
                  onChange={(e) => setLogsPlayers(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="font-semibold text-slate-300">Kriteria Penilaian:</div>
                <div className="grid grid-cols-2 gap-1 text-slate-400">
                  <div>🔴 1 - 3 Pemain</div>
                  <div>🟡 4 - 7 Pemain</div>
                  <div>🟢 8 - 13 Pemain</div>
                  <div>🔵 13+ Pemain</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'bmt' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Attendees Number:
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={bmtNumber}
                    onChange={(e) => setBmtNumber(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Attendees Usernames:
                  </label>
                  <input
                    type="text"
                    value={bmtUsername}
                    onChange={(e) => setBmtUsername(e.target.value)}
                    placeholder="Vulture and sayurkol910"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-emerald-400 block mb-1">
                    Passed (Lulus):
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={bmtPassed}
                    onChange={(e) => setBmtPassed(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-rose-400 block mb-1">
                    Failed (Gagal):
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={bmtFailed}
                    onChange={(e) => setBmtFailed(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-500">
                Otomatis menambahkan counter <span className="text-slate-300">BMTs today</span> (+1) dan <span className="text-slate-300">BMTs this week</span> (+1).
              </p>
            </div>
          )}

          {activeTab === 'tryoutlog' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Type Tryout:
                  </label>
                  <select
                    value={tryoutType}
                    onChange={(e) => setTryoutType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="Succesfull">Succesfull</option>
                    <option value="Unsuccesfull">Unsuccesfull</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Current Rank (Opsional):
                  </label>
                  <input
                    type="text"
                    value={tryoutRank}
                    onChange={(e) => setTryoutRank(e.target.value)}
                    placeholder="Chief of Staff / CoS"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Attendees:
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={tryoutAttendees}
                    onChange={(e) => setTryoutAttendees(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-emerald-400 block mb-1">
                    Passed:
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={tryoutPassed}
                    onChange={(e) => setTryoutPassed(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-rose-400 block mb-1">
                    Failed:
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={tryoutFailed}
                    onChange={(e) => setTryoutFailed(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-500">
                Otomatis memperbarui counter Tryouts today (+1), this week (+1), dan Successful/Unsuccessful ever (+1).
              </p>
            </div>
          )}

          {activeTab === 'army' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  User / Nama Prajurit:
                </label>
                <input
                  type="text"
                  value={armyUser}
                  onChange={(e) => setArmyUser(e.target.value)}
                  placeholder="Contoh: @Username atau Nama"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Rank / Pangkat:
                </label>
                <input
                  type="text"
                  value={armyRank}
                  onChange={(e) => setArmyRank(e.target.value)}
                  placeholder="Contoh: Lieutenant, Private, Commander"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="text-[11px] text-slate-500">
                Otomatis menyertakan ping <span className="text-indigo-400 font-mono">&lt;@1136972263988678727&gt;</span>
              </div>
            </div>
          )}

          {activeTab === 'summary' && (
            <div className="space-y-2 p-3.5 bg-slate-950/60 rounded-xl border border-slate-800 text-xs">
              <div className="font-semibold text-white">Laporan Rangkuman Harian (AEST LOGS SUMMARY)</div>
              <p className="text-slate-400 leading-relaxed">
                Mengambil data semua input <span className="text-indigo-400 font-mono">/logs</span> yang dimasukkan hari ini (14:00 - 20:00).
              </p>
              <div className="text-slate-500 text-[11px]">
                Total slot tercatat hari ini: <span className="text-white font-bold">{botData ? Object.keys(botData.logsToday).length : 0} slot</span>
              </div>
            </div>
          )}

          {/* Action Checkbox & Generate Button */}
          <div className="pt-2 space-y-2.5">
            {activeTab !== 'summary' && (
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={saveToDatabase}
                  onChange={(e) => setSaveToDatabase(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Simpan dan perbarui counter bot secara live</span>
              </label>
            )}

            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 transition disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{loading ? 'Membuat Format...' : `Generate Format /${activeTab}`}</span>
            </button>
          </div>
        </div>

        {/* Right column: Formatted Output & Copy Box */}
        <div className="lg:col-span-7 flex flex-col justify-between bg-slate-950 border border-slate-800 rounded-xl p-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                <span className="text-xs font-semibold text-slate-300">Hasil Format Discord:</span>
              </div>
              {generatedText && (
                <span className="text-[11px] text-emerald-400 font-mono">Siap Dipakai</span>
              )}
            </div>

            {generatedText ? (
              <div className="space-y-3">
                <pre className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 text-xs font-mono text-slate-200 whitespace-pre-wrap select-all leading-relaxed overflow-x-auto max-h-72">
                  {generatedText}
                </pre>
              </div>
            ) : (
              <div className="h-48 flex flex-col items-center justify-center text-center p-6 text-slate-500">
                <Terminal className="w-8 h-8 mb-2 opacity-40" />
                <p className="text-xs">Klik tombol "Generate Format" di sebelah kiri untuk membuat preview teks Discord.</p>
              </div>
            )}
          </div>

          {generatedText && (
            <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
              <span className="text-[11px] text-slate-400">
                Copy teks dan paste langsung ke channel Discord target.
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Berhasil Di-Copy!' : 'Copy Teks'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
