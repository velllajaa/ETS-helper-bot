import { Activity, Clock, Award, Target, UserCheck, FileText, Undo2 } from 'lucide-react';
import { BotData } from '../types';

interface RecentActionsFeedProps {
  botData: BotData | null;
}

export function RecentActionsFeed({ botData }: RecentActionsFeedProps) {
  const actions = botData?.recentActions || [];

  const getIcon = (type: string) => {
    switch (type) {
      case 'logs':
        return <Clock className="w-3.5 h-3.5 text-sky-400" />;
      case 'bmt':
        return <Award className="w-3.5 h-3.5 text-indigo-400" />;
      case 'tryoutlog':
        return <Target className="w-3.5 h-3.5 text-amber-400" />;
      case 'army':
        return <UserCheck className="w-3.5 h-3.5 text-emerald-400" />;
      case 'summary':
        return <FileText className="w-3.5 h-3.5 text-purple-400" />;
      case 'undolog':
      case 'bmtundo':
      case 'tryoutsundo':
        return <Undo2 className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Asia/Jakarta',
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:p-6 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Activity className="w-4 h-4 text-indigo-400" />
          <span>Aktivitas & Log Eksekusi Terkini</span>
        </h3>
        <span className="text-xs text-slate-500">Auto-logged</span>
      </div>

      {actions.length === 0 ? (
        <div className="py-8 text-center text-xs text-slate-500">
          Belum ada aktivitas tercatat hari ini. Coba jalankan command di Discord atau di generator di atas!
        </div>
      ) : (
        <div className="divide-y divide-slate-800/60 max-h-60 overflow-y-auto">
          {actions.map((act) => (
            <div key={act.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-6 h-6 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0">
                  {getIcon(act.type)}
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-slate-200 truncate">{act.title}</div>
                  <div className="text-[11px] text-slate-400 truncate">{act.details}</div>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="font-mono text-[11px] text-slate-400 block">{formatTime(act.timestamp)} WIB</span>
                {act.user && <span className="text-[10px] text-slate-500 truncate block">{act.user}</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
