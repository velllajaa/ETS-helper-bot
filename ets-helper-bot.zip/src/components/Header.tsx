import { Bot, ExternalLink, ShieldCheck, Activity, RefreshCw } from 'lucide-react';
import { BotStatusResponse } from '../types';

interface HeaderProps {
  status: BotStatusResponse | null;
  loading: boolean;
  onRefresh: () => void;
}

export function Header({ status, loading, onRefresh }: HeaderProps) {
  const isOnline = status?.bot.ready ?? false;
  const inviteUrl = status?.config.inviteUrl || 'https://discord.com/oauth2/authorize?client_id=1550366333177307146&permissions=8&integration_type=0&scope=bot';

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Left: Branding & Status */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white tracking-tight">ETS Helper Bot</h1>
              <span className="text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                WIB (UTC+7)
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <span>App ID: <span className="font-mono text-slate-300">1550366333177307146</span></span>
              <span>•</span>
              <span className="text-slate-300">Shift Logs & BMT Tracker</span>
            </p>
          </div>
        </div>

        {/* Right: Live Connection Pill & Actions */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="relative flex h-2 w-2">
              {isOnline ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </>
              ) : (
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
              )}
            </span>
            <span className={isOnline ? 'font-medium text-emerald-400' : 'font-medium text-amber-400'}>
              {isOnline ? 'Bot Online' : 'Connecting / Ready'}
            </span>
            {status?.bot.ping && status.bot.ping >= 0 ? (
              <span className="text-slate-500 border-l border-slate-800 pl-2">
                {status.bot.ping}ms
              </span>
            ) : null}
          </div>

          <button
            onClick={onRefresh}
            disabled={loading}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors"
            title="Refresh Status"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>

          <a
            href={inviteUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-colors"
          >
            <span>Invite ke Server</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
}
