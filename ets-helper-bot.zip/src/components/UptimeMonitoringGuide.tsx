import { useState, useEffect } from 'react';
import { ShieldCheck, Copy, Check, ExternalLink, AlertTriangle, Radio, Server, Info, Zap } from 'lucide-react';

interface UptimeGuideProps {
  apiBaseUrl: string;
}

export function UptimeMonitoringGuide({ apiBaseUrl }: UptimeGuideProps) {
  const [copied, setCopied] = useState(false);
  const [pingStatus, setPingStatus] = useState<{ testing: boolean; result: string | null; timeMs: number | null }>({
    testing: false,
    result: null,
    timeMs: null,
  });

  // If running in development domain (ais-dev-), provide the public shared URL (ais-pre-) for external tools like UptimeRobot
  const publicSharedOrigin = apiBaseUrl.replace('ais-dev-', 'ais-pre-');
  const fullHealthUrl = `${publicSharedOrigin || apiBaseUrl}/api/health`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullHealthUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const testPing = async () => {
    setPingStatus({ testing: true, result: null, timeMs: null });
    const start = performance.now();
    try {
      const res = await fetch('/api/health');
      const timeMs = Math.round(performance.now() - start);
      if (res.ok) {
        const json = await res.json();
        setPingStatus({
          testing: false,
          result: `200 OK (Status: ${json.status}, Bot: ${json.bot?.ready ? 'Online' : 'Connecting'})`,
          timeMs,
        });
      } else {
        setPingStatus({
          testing: false,
          result: `HTTP Error ${res.status}`,
          timeMs,
        });
      }
    } catch (err: any) {
      setPingStatus({
        testing: false,
        result: `Fetch Error: ${err.message}`,
        timeMs: null,
      });
    }
  };

  useEffect(() => {
    testPing();
  }, []);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 lg:p-6 shadow-xl relative overflow-hidden">
      <div className="absolute -top-24 -right-24 w-60 h-60 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Link UptimeRobot 24/7 (Anti-Sleep & Anti-404)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Endpoint ini dijamin merespons <span className="font-semibold text-emerald-400">HTTP 200 OK</span> tanpa 404 untuk menjaga bot tetap menyala.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={testPing}
            disabled={pingStatus.testing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>{pingStatus.testing ? 'Menguji...' : 'Test Ping Sekarang'}</span>
          </button>
          <a
            href="https://uptimerobot.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition"
          >
            <span>Buka UptimeRobot</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Target URL Box */}
      <div className="mt-4">
        <label className="text-xs font-medium text-slate-400 mb-1.5 block">
          URL Khusus untuk UptimeRobot:
        </label>
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl p-2.5">
          <code className="text-xs font-mono text-emerald-400 flex-1 overflow-x-auto select-all">
            {fullHealthUrl}
          </code>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition shrink-0"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Tersalin!' : 'Copy Link'}</span>
          </button>
        </div>

        {pingStatus.result && (
          <div className="mt-2 flex items-center gap-2 text-xs text-slate-400">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Hasil Ping Terakhir:</span>
            <span className="font-mono text-emerald-400">{pingStatus.result}</span>
            {pingStatus.timeMs !== null && (
              <span className="text-slate-500">({pingStatus.timeMs}ms)</span>
            )}
          </div>
        )}
      </div>

      {/* Accordion / Info Box: Cara Pasang & Penjelasan Vercel */}
      <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs">
        {/* Step by step UptimeRobot */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
          <div className="flex items-center gap-2 font-semibold text-slate-200 mb-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Cara Pasang di UptimeRobot (Agar Tidak 403 / Error):</span>
          </div>
          <ol className="list-decimal list-inside space-y-1.5 text-slate-400 leading-relaxed">
            <li>Daftar / Login ke <span className="text-slate-200">UptimeRobot.com</span></li>
            <li>Klik tombol <span className="text-slate-200 font-medium">+ Add New Monitor</span></li>
            <li>Pilih Monitor Type: <span className="text-emerald-400 font-medium">HTTP(s)</span></li>
            <li>
              Masukkan URL di atas: <code className="text-emerald-400 font-mono text-[11px] bg-slate-900 px-1 py-0.5 rounded">https://ais-pre-25e2eu7cevd63l2vm6ihyj-523030325674.asia-southeast1.run.app/api/health</code>
            </li>
            <li>Monitoring Interval: atur ke <span className="text-amber-400 font-medium">5 minutes</span></li>
            <li>Klik <span className="text-slate-200 font-medium">Create Monitor</span>. Selesai! UptimeRobot akan otomatis mem-ping bot Anda tanpa hambatan.</li>
          </ol>
        </div>

        {/* Why Vercel is not for Discord Bots */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-amber-500/20">
          <div className="flex items-center gap-2 font-semibold text-amber-400 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Pertanyaan Anda: Boleh Upload ke Vercel?</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            <span className="font-semibold text-red-400">Jawabannya: TIDAK BISA di Vercel!</span> Vercel adalah arsitektur <em>Serverless</em> yang otomatis mati setelah 10-15 detik. Discord Bot memerlukan koneksi WebSocket Gateway yang terus berjalan non-stop. Jika di Vercel, bot akan langsung offline.
          </p>
          <div className="mt-2 pt-2 border-t border-slate-800 text-slate-400">
            <span className="text-slate-200 font-medium">Opsi 24/7 Terbaik:</span> Gunakan URL Cloud Run di atas dengan UptimeRobot, atau deploy source code ini ke <span className="text-indigo-400 font-medium">Render.com (Web Service gratis)</span>, <span className="text-indigo-400 font-medium">Railway</span>, atau <span className="text-indigo-400 font-medium">VPS</span>.
          </div>
        </div>
      </div>
    </div>
  );
}
