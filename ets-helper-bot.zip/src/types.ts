export interface ShiftLogEntry {
  timeSlot: string;
  players: number;
  ratingEmoji: string;
  timestamp: number;
}

export interface BotData {
  date: string;
  week: string;
  logsToday: Record<string, ShiftLogEntry>;
  bmts: {
    today: number;
    thisWeek: number;
  };
  tryouts: {
    today: number;
    successfulEver: number;
    unsuccessfulEver: number;
    thisWeek: number;
  };
  recentActions: {
    id: string;
    type: 'logs' | 'bmt' | 'tryoutlog' | 'army' | 'summary' | 'undolog' | 'bmtundo' | 'tryoutsundo';
    title: string;
    details: string;
    timestamp: number;
    user?: string;
  }[];
}

export interface BotStatusResponse {
  bot: {
    ready: boolean;
    username: string;
    tag: string;
    id: string;
    ping: number;
    uptimeSeconds: number;
    guildsCount: number;
    loginError: string | null;
    lastConnected: string | null;
  };
  config: {
    clientId: string;
    inviteUrl: string;
  };
  jakartaTime: {
    date: string;
    week: string;
    iso: string;
  };
}
