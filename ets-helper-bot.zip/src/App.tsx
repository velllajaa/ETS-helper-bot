import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { UptimeMonitoringGuide } from './components/UptimeMonitoringGuide';
import { StatsCounterCards } from './components/StatsCounterCards';
import { CommandGenerators } from './components/CommandGenerators';
import { UndoControlsPanel } from './components/UndoControlsPanel';
import { ShiftTimeline } from './components/ShiftTimeline';
import { RecentActionsFeed } from './components/RecentActionsFeed';
import { BotData, BotStatusResponse } from './types';
import { Shield, Sparkles, BookOpen, AlertCircle, Undo2 } from 'lucide-react';

export default function App() {
  const [botStatus, setBotStatus] = useState<BotStatusResponse | null>(null);
  const [botData, setBotData] = useState<BotData | null>(null);
  const [loading, setLoading] = useState(false);
  const [apiBaseUrl, setApiBaseUrl] = useState('');

  useEffect(() => {
    setApiBaseUrl(window.location.origin);
  }, []);

  const fetchBotStatus = async (retries = 2) => {
    try {
      const res = await fetch('/api/bot-status');
      if (res.ok) {
        const data = await res.json();
        setBotStatus(data);
      }
    } catch (err) {
      if (retries > 0) {
        setTimeout(() => fetchBotStatus(retries - 1), 1000);
      } else {
        console.warn('Failed to fetch bot status after retries:', err);
      }
    }
  };

  const fetchBotData = async (retries = 2) => {
    try {
      const res = await fetch('/api/bot-data');
      if (res.ok) {
        const data = await res.json();
        setBotData(data);
      }
    } catch (err) {
      if (retries > 0) {
        setTimeout(() => fetchBotData(retries - 1), 1000);
      } else {
        console.warn('Failed to fetch bot data after retries:', err);
      }
    }
  };

  const refreshAll = async () => {
    setLoading(true);
    await Promise.all([fetchBotStatus(), fetchBotData()]);
    setLoading(false);
  };

  useEffect(() => {
    refreshAll();
    const interval = setInterval(() => {
      fetchBotStatus();
      fetchBotData();
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleUpdateCounters = async (updates: Partial<BotData>) => {
    try {
      const res = await fetch('/api/bot-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.data) setBotData(json.data);
      }
    } catch (err) {
      console.error('Failed to update counters:', err);
    }
  };

  const handleQuickLog = async (waktu: string, players: number) => {
    try {
      const res = await fetch('/api/generate-preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: 'logs',
          payload: { waktu, players, save: true },
        }),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.botData) setBotData(json.botData);
      }
    } catch (err) {
      console.error('Failed to quick log:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white flex flex-col">
      <Header status={botStatus} loading={loading} onRefresh={refreshAll} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Connection Notice / Error if any */}
        {botStatus?.bot.loginError && (
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-200">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Info Koneksi Discord:</span>{' '}
              {botStatus.bot.loginError} (Pastikan Bot Token dan Privileged Gateway Intents aktif di Discord Developer Portal).
            </div>
          </div>
        )}

        {/* 1. UptimeRobot Guide & Ping URL */}
        <UptimeMonitoringGuide apiBaseUrl={apiBaseUrl} />

        {/* 2. Real-time stats & counters */}
        <StatsCounterCards data={botData} onUpdateCounters={handleUpdateCounters} />

        {/* 3. Shift Timeline 30 Menit */}
        <ShiftTimeline botData={botData} onQuickLog={handleQuickLog} />

        {/* 4. Command Generator & Formatter */}
        <CommandGenerators botData={botData} onRefreshData={fetchBotData} />

        {/* 5. Undo Controls Panel */}
        <UndoControlsPanel botData={botData} onRefreshData={fetchBotData} />

        {/* 6. Recent Activity Feed */}
        <RecentActionsFeed botData={botData} />

        {/* Reference Cheat Sheet */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 text-xs text-slate-400 space-y-3">
          <div className="flex items-center gap-2 font-bold text-slate-200">
            <BookOpen className="w-4 h-4 text-indigo-400" />
            <span>Referensi Slash Command ETS Bot di Discord:</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-indigo-400 font-semibold mb-1">/logs [waktu] [players]</div>
              <p className="text-slate-400">Laporan shift tiap 30 menit (14:00 - 20:00 WIB) dengan rating otomatis & tombol copy.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-indigo-400 font-semibold mb-1">/bmt [number] [username] [passed] [failed]</div>
              <p className="text-slate-400">Mencatat kegiatan Basic Military Training, menambah counter BMT today & this week.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-indigo-400 font-semibold mb-1">/tryoutlog [type] [att] [passed] [failed]</div>
              <p className="text-slate-400">Mencatat tryouts (Succesfull/Unsuccesfull) dan melacak histori sukses/gagal selamanya.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-rose-400 font-semibold mb-1">/undolog</div>
              <p className="text-slate-400">Menghapus log shift 30 menit yang terakhir dimasukkan sebanyak 1x.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-rose-400 font-semibold mb-1">/bmtundo</div>
              <p className="text-slate-400">Menghapus 1x log BMT terakhir serta mengembalikan hitungan today & this week.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-rose-400 font-semibold mb-1">/tryouts undo (atau /tryoutsundo)</div>
              <p className="text-slate-400">Menghapus 1x log tryout terakhir serta membatalkan counter sukses/gagal terkait.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-indigo-400 font-semibold mb-1">/army [user] [rank]</div>
              <p className="text-slate-400">Mencatat data prajurit Army dengan tag ping otomatis.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-indigo-400 font-semibold mb-1">/summary</div>
              <p className="text-slate-400">Merekap seluruh data logs 30 menit hari itu dalam format AEST LOGS SUMMARY.</p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="font-mono text-emerald-400 font-semibold mb-1">Tombol "📋 Copy Teks"</div>
              <p className="text-slate-400">Tiap command di Discord dilengkapi tombol interactive untuk copy format tanpa ribet.</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <p>ETS Helper Bot • Discord Bot & Management Operations Control Dashboard • WIB (UTC+7)</p>
      </footer>
    </div>
  );
}
