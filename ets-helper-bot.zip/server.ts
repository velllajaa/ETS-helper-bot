import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  startDiscordBot,
  getBotStatus,
  BOT_CONFIG,
  formatLogsOutput,
  formatBmtOutput,
  formatTryoutOutput,
  formatArmyOutput,
  formatSummaryOutput,
} from './server/discordBot.js';
import {
  loadBotData,
  saveBotData,
  getJakartaDate,
  undoLogLast,
  undoBmtLast,
  undoTryoutLast,
} from './server/dataStore.js';

const app = express();
const PORT = 3000;

// Enable CORS and JSON parsing
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json());

// UptimeRobot / Ping endpoints (Guaranteed 200 OK - will not 404)
app.get(['/api/health', '/health'], (req, res) => {
  const bot = getBotStatus();
  res.status(200).json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    bot: {
      ready: bot.ready,
      tag: bot.tag,
      ping: bot.ping,
      guilds: bot.guildsCount,
      error: bot.loginError,
    },
  });
});

app.get(['/api/ping', '/ping'], (req, res) => {
  res.status(200).send('pong');
});

// Bot status and configuration
app.get('/api/bot-status', (req, res) => {
  const bot = getBotStatus();
  const { dateStr, weekStr } = getJakartaDate();
  res.json({
    bot,
    config: {
      clientId: BOT_CONFIG.clientId,
      inviteUrl: BOT_CONFIG.inviteUrl,
    },
    jakartaTime: {
      date: dateStr,
      week: weekStr,
      iso: new Date().toISOString(),
    },
  });
});

// Bot live data store
app.get('/api/bot-data', (req, res) => {
  const data = loadBotData();
  res.json(data);
});

// Update data manually or add a log entry from Web UI
app.post('/api/bot-data', (req, res) => {
  const current = loadBotData();
  const updates = req.body;

  if (updates.bmts) {
    if (typeof updates.bmts.today === 'number') current.bmts.today = updates.bmts.today;
    if (typeof updates.bmts.thisWeek === 'number') current.bmts.thisWeek = updates.bmts.thisWeek;
  }

  if (updates.tryouts) {
    if (typeof updates.tryouts.today === 'number') current.tryouts.today = updates.tryouts.today;
    if (typeof updates.tryouts.successfulEver === 'number') current.tryouts.successfulEver = updates.tryouts.successfulEver;
    if (typeof updates.tryouts.unsuccessfulEver === 'number') current.tryouts.unsuccessfulEver = updates.tryouts.unsuccessfulEver;
    if (typeof updates.tryouts.thisWeek === 'number') current.tryouts.thisWeek = updates.tryouts.thisWeek;
  }

  saveBotData(current);
  res.json({ success: true, data: current });
});

// Generate and preview any command format directly from web dashboard
app.post('/api/generate-preview', (req, res) => {
  const { command, payload } = req.body;
  const botData = loadBotData();

  if (command === 'logs') {
    const { waktu, players } = payload;
    const { text, timestamp, ratingEmoji } = formatLogsOutput(waktu, Number(players));
    // Also save if saveOption is requested
    if (payload.save) {
      botData.logsToday[waktu] = {
        timeSlot: waktu,
        players: Number(players),
        ratingEmoji,
        timestamp,
      };
      botData.recentActions.unshift({
        id: `web_${Date.now()}`,
        type: 'logs',
        title: `/logs ${waktu} (Web)`,
        details: `${players} players (${ratingEmoji})`,
        timestamp: Date.now(),
        user: 'Web Dashboard',
      });
      saveBotData(botData);
    }
    return res.json({ formattedText: text, timestamp, ratingEmoji, botData });
  }

  if (command === 'bmt') {
    const { attendeesNumber, attendeesUsername, passed, failed, save } = payload;
    const num = Number(attendeesNumber);
    const pass = Number(passed);
    const fail = Number(failed);

    let todayCount = botData.bmts.today;
    let weekCount = botData.bmts.thisWeek;

    if (save) {
      todayCount += 1;
      weekCount += 1;
      botData.bmts.today = todayCount;
      botData.bmts.thisWeek = weekCount;
      botData.recentActions.unshift({
        id: `web_${Date.now()}`,
        type: 'bmt',
        title: `/bmt (${num} attendees) (Web)`,
        details: `Passed: ${pass}, Failed: ${fail}`,
        timestamp: Date.now(),
        user: 'Web Dashboard',
      });
      saveBotData(botData);
    }

    const text = formatBmtOutput(num, attendeesUsername, pass, fail, todayCount, weekCount);
    return res.json({ formattedText: text, botData });
  }

  if (command === 'tryoutlog') {
    const { type, attendees, passed, failed, currentRank, save } = payload;
    const att = Number(attendees);
    const pass = Number(passed);
    const fail = Number(failed);
    const rank = currentRank || 'CoS';

    let todayCount = botData.tryouts.today;
    let weekCount = botData.tryouts.thisWeek;
    let successCount = botData.tryouts.successfulEver;
    let failCount = botData.tryouts.unsuccessfulEver;

    if (save) {
      todayCount += 1;
      weekCount += 1;
      if (type === 'Succesfull') {
        successCount += 1;
      } else {
        failCount += 1;
      }
      botData.tryouts.today = todayCount;
      botData.tryouts.thisWeek = weekCount;
      botData.tryouts.successfulEver = successCount;
      botData.tryouts.unsuccessfulEver = failCount;

      botData.recentActions.unshift({
        id: `web_${Date.now()}`,
        type: 'tryoutlog',
        title: `/tryoutlog ${type} (Web)`,
        details: `Passed: ${pass}, Failed: ${fail}, Rank: ${rank}`,
        timestamp: Date.now(),
        user: 'Web Dashboard',
      });
      saveBotData(botData);
    }

    const text = formatTryoutOutput(type, att, pass, fail, rank, todayCount, successCount, failCount, weekCount);
    return res.json({ formattedText: text, botData });
  }

  if (command === 'army') {
    const { user, rank } = payload;
    const text = formatArmyOutput(user, rank);
    return res.json({ formattedText: text, botData });
  }

  if (command === 'summary') {
    const text = formatSummaryOutput(botData);
    return res.json({ formattedText: text, botData });
  }

  res.status(400).json({ error: 'Unknown command' });
});

// Direct Undo API endpoint for dashboard and web control
app.post('/api/undo', (req, res) => {
  const { type } = req.body; // 'logs' | 'bmt' | 'tryout'
  const botData = loadBotData();

  if (type === 'logs' || type === 'undolog') {
    const result = undoLogLast(botData, 'Web Dashboard');
    return res.json({ ...result, botData });
  }

  if (type === 'bmt' || type === 'bmtundo') {
    const result = undoBmtLast(botData, 'Web Dashboard');
    return res.json({ ...result, botData });
  }

  if (type === 'tryout' || type === 'tryoutlog' || type === 'tryoutsundo') {
    const result = undoTryoutLast(botData, 'Web Dashboard');
    return res.json({ ...result, botData });
  }

  return res.status(400).json({ success: false, message: 'Invalid undo type' });
});

async function start() {
  // Start Discord Bot client
  startDiscordBot().catch((err) => {
    console.error('Failed to start Discord Bot:', err);
  });

  // Vite middleware in dev, static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ETS Helper] Server listening on http://0.0.0.0:${PORT}`);
  });
}

start();
